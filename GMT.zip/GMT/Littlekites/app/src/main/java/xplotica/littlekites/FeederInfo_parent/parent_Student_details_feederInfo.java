package xplotica.littlekites.FeederInfo_parent;

/**
 * Created by santa on 3/1/2017.
 */
public class parent_Student_details_feederInfo {


    private String _school;
    private String _student;
    private String _rollno;


    public String get_school() {
        return _school;
    }

    public void set_school(String _school) {
        this._school = _school;
    }

    public String get_student() {
        return _student;
    }

    public void set_student(String _student) {
        this._student = _student;
    }

    public String get_rollno() {
        return _rollno;
    }

    public void set_rollno(String _rollno) {
        this._rollno = _rollno;
    }
}
