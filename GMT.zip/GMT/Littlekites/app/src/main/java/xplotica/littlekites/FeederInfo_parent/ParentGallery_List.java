package xplotica.littlekites.FeederInfo_parent;

/**
 * Created by santa on 3/21/2017.
 */
public class ParentGallery_List {


    int thumbnail;
    String galleryid;
    String strthumbnail;
    String strthumbnailurl;
    String textcount;

    public String getStrthumbnailurl() {
        return strthumbnailurl;
    }

    public void setStrthumbnailurl(String strthumbnailurl) {
        this.strthumbnailurl = strthumbnailurl;
    }

    public String getGalleryid() {
        return galleryid;
    }

    public void setGalleryid(String galleryid) {
        this.galleryid = galleryid;
    }

    public String getStrthumbnail() {
        return strthumbnail;
    }

    public void setStrthumbnail(String strthumbnail) {
        this.strthumbnail = strthumbnail;
    }

    public int getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(int thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getTextcount() {
        return textcount;
    }

    public void setTextcount(String textcount) {
        this.textcount = textcount;
    }

    public String getTextname() {
        return textname;
    }

    public void setTextname(String textname) {
        this.textname = textname;
    }

    String textname;





}
