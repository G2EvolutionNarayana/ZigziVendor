package xplotica.littlekites.FeederInfo_parent;

/**
 * Created by G2evolution on 5/1/2017.
 */

public class HolidayEntity {
    private String schoolid;
    private String schoolname;

    public String getSchoolid() {
        return schoolid;
    }

    public void setSchoolid(String schoolid) {
        this.schoolid = schoolid;
    }

    public String getSchoolname() {
        return schoolname;
    }

    public void setSchoolname(String schoolname) {
        this.schoolname = schoolname;
    }

    public String getHolidayid() {
        return holidayid;
    }

    public void setHolidayid(String holidayid) {
        this.holidayid = holidayid;
    }

    public String getHolidaytitle() {
        return holidaytitle;
    }

    public void setHolidaytitle(String holidaytitle) {
        this.holidaytitle = holidaytitle;
    }

    public String getHolidaydesc() {
        return holidaydesc;
    }

    public void setHolidaydesc(String holidaydesc) {
        this.holidaydesc = holidaydesc;
    }

    public String getHolidaydate() {
        return holidaydate;
    }

    public void setHolidaydate(String holidaydate) {
        this.holidaydate = holidaydate;
    }

    private String holidayid;
    private String holidaytitle;
    private String holidaydesc;
    private String holidaydate;
}
