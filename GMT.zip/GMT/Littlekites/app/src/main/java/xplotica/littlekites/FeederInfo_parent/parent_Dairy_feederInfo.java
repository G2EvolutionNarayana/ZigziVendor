package xplotica.littlekites.FeederInfo_parent;

/**
 * Created by santa on 3/30/2017.
 */
public class parent_Dairy_feederInfo {


    private String dairyid;
    private String date;
    private String _topicName;
    private String _time;
    private String _message;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDairyid() {
        return dairyid;
    }

    public void setDairyid(String dairyid) {
        this.dairyid = dairyid;
    }

    public String get_topicName() {
        return _topicName;
    }

    public void set_topicName(String _topicName) {
        this._topicName = _topicName;
    }

    public String get_time() {
        return _time;
    }

    public void set_time(String _time) {
        this._time = _time;
    }

    public String get_message() {
        return _message;
    }

    public void set_message(String _message) {
        this._message = _message;
    }
}
