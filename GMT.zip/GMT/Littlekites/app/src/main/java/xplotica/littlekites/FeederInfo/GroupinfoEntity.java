package xplotica.littlekites.FeederInfo;

/**
 * Created by G2evolution on 3/27/2017.
 */
public class GroupinfoEntity {

    private String groupmemberid;
    private String groupid;
    private String ownerid;
    private String underon;
    private String groupmemberstatus;
    private String groupname;
    private String username ;
    private String usertype;

    public String getGroupmemberid() {
        return groupmemberid;
    }

    public void setGroupmemberid(String groupmemberid) {
        this.groupmemberid = groupmemberid;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getOwnerid() {
        return ownerid;
    }

    public void setOwnerid(String ownerid) {
        this.ownerid = ownerid;
    }

    public String getUnderon() {
        return underon;
    }

    public void setUnderon(String underon) {
        this.underon = underon;
    }

    public String getGroupmemberstatus() {
        return groupmemberstatus;
    }

    public void setGroupmemberstatus(String groupmemberstatus) {
        this.groupmemberstatus = groupmemberstatus;
    }

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    private String userid;





}