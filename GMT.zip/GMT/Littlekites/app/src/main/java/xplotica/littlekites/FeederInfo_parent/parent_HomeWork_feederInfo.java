package xplotica.littlekites.FeederInfo_parent;

/**
 * Created by santa on 3/30/2017.
 */
public class parent_HomeWork_feederInfo {

    private String _topicName;
    private String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String get_subject() {
        return _subject;
    }

    public void set_subject(String _subject) {
        this._subject = _subject;
    }

    private String _time;
    private String _message;
    private String _subject;

    public String get_topicName() {
        return _topicName;
    }

    public void set_topicName(String _topicName) {
        this._topicName = _topicName;
    }

    public String get_time() {
        return _time;
    }

    public void set_time(String _time) {
        this._time = _time;
    }

    public String get_message() {
        return _message;
    }

    public void set_message(String _message) {
        this._message = _message;
    }
}
