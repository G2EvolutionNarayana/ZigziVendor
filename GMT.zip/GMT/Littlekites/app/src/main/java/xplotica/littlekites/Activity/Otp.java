package xplotica.littlekites.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import xplotica.littlekites.R;


public class Otp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
    }
}
