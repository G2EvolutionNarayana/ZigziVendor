package xplotica.littlekites.FeederInfo;


public class Json_Data1 {

    private String Name;
    private String Id;

    public String getName() {
        return Name;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public void setName(String name) {
        Name = name;
    }
}
