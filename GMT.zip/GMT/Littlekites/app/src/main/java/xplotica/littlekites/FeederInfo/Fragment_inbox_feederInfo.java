package xplotica.littlekites.FeederInfo;

/**
 * Created by santa on 3/1/2017.
 */
public class Fragment_inbox_feederInfo {

    private String _topic;
    private String _rollno;
    private String _name;
    private String _section;
    private String _message;

    public String get_topic() {
        return _topic;
    }

    public void set_topic(String _topic) {
        this._topic = _topic;
    }

    public String get_rollno() {
        return _rollno;
    }

    public void set_rollno(String _rollno) {
        this._rollno = _rollno;
    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    public String get_section() {
        return _section;
    }

    public void set_section(String _section) {
        this._section = _section;
    }

    public String get_message() {
        return _message;
    }

    public void set_message(String _message) {
        this._message = _message;
    }
}
