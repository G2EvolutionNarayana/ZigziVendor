package xplotica.littlekites.FeederInfo_parent;

/**
 * Created by G2evolution on 5/1/2017.
 */

public class Parent_Notice_feederInfo {
    private String noticeid;
    private String schoolid;
    private String noticedate;
    private String noticedescription;

    public String getNoticeid() {
        return noticeid;
    }

    public void setNoticeid(String noticeid) {
        this.noticeid = noticeid;
    }

    public String getSchoolid() {
        return schoolid;
    }

    public void setSchoolid(String schoolid) {
        this.schoolid = schoolid;
    }

    public String getNoticedate() {
        return noticedate;
    }

    public void setNoticedate(String noticedate) {
        this.noticedate = noticedate;
    }

    public String getNoticedescription() {
        return noticedescription;
    }

    public void setNoticedescription(String noticedescription) {
        this.noticedescription = noticedescription;
    }
}
