package xplotica.littlekites.FeederInfo;

/**
 * Created by G2evolution on 3/27/2017.
 */
public class GroupEntity {


    private String homegroupid;
    private String homegroupteacherid;
    private String homegroupname;
    private String homegroupteachername;

    public String getHomegroupteacherid() {
        return homegroupteacherid;
    }

    public void setHomegroupteacherid(String homegroupteacherid) {
        this.homegroupteacherid = homegroupteacherid;
    }

    public String getHomegroupname() {
        return homegroupname;
    }

    public void setHomegroupname(String homegroupname) {
        this.homegroupname = homegroupname;
    }

    public String getHomegroupteachername() {
        return homegroupteachername;
    }

    public void setHomegroupteachername(String homegroupteachername) {
        this.homegroupteachername = homegroupteachername;
    }

    public String getHomegroupstatus() {
        return homegroupstatus;
    }

    public void setHomegroupstatus(String homegroupstatus) {
        this.homegroupstatus = homegroupstatus;
    }

    private String homegroupstatus;

    public String getHomegroupid() {
        return homegroupid;
    }

    public void setHomegroupid(String homegroupid) {
        this.homegroupid = homegroupid;
    }
}