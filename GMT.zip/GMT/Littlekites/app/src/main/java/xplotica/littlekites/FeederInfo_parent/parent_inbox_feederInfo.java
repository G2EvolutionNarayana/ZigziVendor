package xplotica.littlekites.FeederInfo_parent;

import java.util.Date;

/**
 * Created by santa on 3/29/2017.
 */
public class parent_inbox_feederInfo {

    String message;
    String time;
    Date date;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
