package xplotica.littlekites.FeederInfo;

/**
 * Created by Sujata on 29-03-2017.
 */
public class Number1 {

    private String ONEs;
    private String textONEs;
    private String textrolnno;
    private boolean isSelected;

    public String getTextrolnno() {
        return textrolnno;
    }

    public void setTextrolnno(String textrolnno) {
        this.textrolnno = textrolnno;
    }

    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    public String getTextONEs() {
        return textONEs;

    }

    public void setTextONEs(String textONEs) {
        this.textONEs = textONEs;
    }

    public String getONEs() {
        return ONEs;
    }

    public void setONEs(String ONEs) {
        this.ONEs = ONEs;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
