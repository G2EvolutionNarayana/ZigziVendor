package xplotica.littlekites.FeederInfo;

/**
 * Created by G2evolution on 5/10/2017.
 */

public class Details_feederInfo {


    private String schoolid;
    private String schoolname;
    private String classid;
    private String classname;
    private String sectionid;
    private String sectionname;

    public String getSchoolid() {
        return schoolid;
    }

    public void setSchoolid(String schoolid) {
        this.schoolid = schoolid;
    }

    public String getSchoolname() {
        return schoolname;
    }

    public void setSchoolname(String schoolname) {
        this.schoolname = schoolname;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getSectionid() {
        return sectionid;
    }

    public void setSectionid(String sectionid) {
        this.sectionid = sectionid;
    }

    public String getSectionname() {
        return sectionname;
    }

    public void setSectionname(String sectionname) {
        this.sectionname = sectionname;
    }

    public String getLoginid() {
        return loginid;
    }

    public void setLoginid(String loginid) {
        this.loginid = loginid;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getLogintype() {
        return logintype;
    }

    public void setLogintype(String logintype) {
        this.logintype = logintype;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getIdentifyno() {
        return identifyno;
    }

    public void setIdentifyno(String identifyno) {
        this.identifyno = identifyno;
    }

    public String getClassteacherid() {
        return classteacherid;
    }

    public void setClassteacherid(String classteacherid) {
        this.classteacherid = classteacherid;
    }

    public String getClassteachername() {
        return classteachername;
    }

    public void setClassteachername(String classteachername) {
        this.classteachername = classteachername;
    }

    private String loginid;
    private String loginname;
    private String logintype;
    private String mobileno;
    private String identifyno;
    private String classteacherid;
    private String classteachername;


}

