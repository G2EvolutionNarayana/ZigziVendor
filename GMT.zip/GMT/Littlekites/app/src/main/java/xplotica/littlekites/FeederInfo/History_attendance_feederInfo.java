package xplotica.littlekites.FeederInfo;

/**
 * Created by santa on 3/1/2017.
 */
public class History_attendance_feederInfo {

    private String _studentid;
    private String _studentname;

    public String get_studentid() {
        return _studentid;
    }

    public void set_studentid(String _studentid) {
        this._studentid = _studentid;
    }

    public String get_studentname() {
        return _studentname;
    }

    public void set_studentname(String _studentname) {
        this._studentname = _studentname;
    }
}
