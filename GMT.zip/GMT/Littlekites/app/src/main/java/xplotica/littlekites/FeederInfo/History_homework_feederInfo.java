package xplotica.littlekites.FeederInfo;

/**
 * Created by santa on 3/1/2017.
 */
public class History_homework_feederInfo {

    private String _topic;
    private String _topic_details;

    public String get_topic() {
        return _topic;
    }

    public void set_topic(String _topic) {
        this._topic = _topic;
    }

    public String get_topic_details() {
        return _topic_details;
    }

    public void set_topic_details(String _topic_details) {
        this._topic_details = _topic_details;
    }
}
