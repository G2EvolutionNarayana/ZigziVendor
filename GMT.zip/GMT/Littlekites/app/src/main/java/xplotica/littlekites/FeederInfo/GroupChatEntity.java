package xplotica.littlekites.FeederInfo;

/**
 * Created by G2evolution on 3/27/2017.
 */
public class GroupChatEntity {


    private String homemessageid;
    private String homesendername;
    private String homeloginid;

    public String getHomesendername() {
        return homesendername;
    }

    public void setHomesendername(String homesendername) {
        this.homesendername = homesendername;
    }

    private String homeusertype;
    private String homegroupid;
    private String homegroupmessage;

    public String getHomegroupmessagestatus() {
        return homegroupmessagestatus;
    }

    public void setHomegroupmessagestatus(String homegroupmessagestatus) {
        this.homegroupmessagestatus = homegroupmessagestatus;
    }

    private String homegroupmessagestatus;

    public String getHomeloginid() {
        return homeloginid;
    }

    public void setHomeloginid(String homeloginid) {
        this.homeloginid = homeloginid;
    }

    public String getHomeusertype() {
        return homeusertype;
    }

    public void setHomeusertype(String homeusertype) {
        this.homeusertype = homeusertype;
    }

    public String getHomegroupid() {
        return homegroupid;
    }

    public void setHomegroupid(String homegroupid) {
        this.homegroupid = homegroupid;
    }

    public String getHomegroupmessage() {
        return homegroupmessage;
    }

    public void setHomegroupmessage(String homegroupmessage) {
        this.homegroupmessage = homegroupmessage;
    }

    public String getHomedate() {
        return homedate;
    }

    public void setHomedate(String homedate) {
        this.homedate = homedate;
    }

    public String getHomegroupname() {
        return homegroupname;
    }

    public void setHomegroupname(String homegroupname) {
        this.homegroupname = homegroupname;
    }

    public String getHomegroupimage() {
        return homegroupimage;
    }

    public void setHomegroupimage(String homegroupimage) {
        this.homegroupimage = homegroupimage;
    }

    private String homedate;
    private String homegroupname;
    private String homegroupimage;

    public String getHomemessageid() {
        return homemessageid;
    }

    public void setHomemessageid(String homemessageid) {
        this.homemessageid = homemessageid;
    }


}