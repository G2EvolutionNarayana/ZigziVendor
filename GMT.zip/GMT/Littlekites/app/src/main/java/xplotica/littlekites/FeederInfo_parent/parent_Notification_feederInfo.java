package xplotica.littlekites.FeederInfo_parent;

/**
 * Created by santa on 3/1/2017.
 */
public class parent_Notification_feederInfo {

    private int photo;
    private String name;

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
