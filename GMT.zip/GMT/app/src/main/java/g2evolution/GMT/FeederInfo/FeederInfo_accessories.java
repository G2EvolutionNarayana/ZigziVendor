package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_accessories {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccname() {
        return accname;
    }

    public void setAccname(String accname) {
        this.accname = accname;
    }

    public String getAccdetail1() {
        return accdetail1;
    }

    public void setAccdetail1(String accdetail1) {
        this.accdetail1 = accdetail1;
    }

    public String getAccprice() {
        return accprice;
    }

    public void setAccprice(String accprice) {
        this.accprice = accprice;
    }

    public String getAccimage() {
        return accimage;
    }

    public void setAccimage(String accimage) {
        this.accimage = accimage;
    }

    private String id;
    private String accname;
    private String accdetail1;
    private String accprice;
    private String accimage;














}
