package g2evolution.GMT.FeederInfo;

/**
 * Created by G2evolution on 2/27/2018.
 */

public class FeederInfo_address {


    private String id;
    private String textname;
    private String textaddress;
    private String textlandmark;
    private String textmobileno;
    private String textpincode;
    private String impnotice;
    private String emailId;
    private String latitude;
    private String logitude;
    private String landMark1;

    public String getLandMark1() {
        return landMark1;
    }

    public void setLandMark1(String landMark1) {
        this.landMark1 = landMark1;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLogitude() {
        return logitude;
    }

    public void setLogitude(String logitude) {
        this.logitude = logitude;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getImpnotice() {
        return impnotice;
    }

    public void setImpnotice(String impnotice) {
        this.impnotice = impnotice;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTextname() {
        return textname;
    }

    public void setTextname(String textname) {
        this.textname = textname;
    }

    public String getTextaddress() {
        return textaddress;
    }

    public void setTextaddress(String textaddress) {
        this.textaddress = textaddress;
    }

    public String getTextlandmark() {
        return textlandmark;
    }

    public void setTextlandmark(String textlandmark) {
        this.textlandmark = textlandmark;
    }

    public String getTextmobileno() {
        return textmobileno;
    }

    public void setTextmobileno(String textmobileno) {
        this.textmobileno = textmobileno;
    }

    public String getTextpincode() {
        return textpincode;
    }

    public void setTextpincode(String textpincode) {
        this.textpincode = textpincode;
    }
}

