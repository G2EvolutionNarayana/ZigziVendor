package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_photo {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhoname() {
        return phoname;
    }

    public void setPhoname(String phoname) {
        this.phoname = phoname;
    }

    public String getPhodetail1() {
        return phodetail1;
    }

    public void setPhodetail1(String phodetail1) {
        this.phodetail1 = phodetail1;
    }

    public String getPhoprice() {
        return phoprice;
    }

    public void setPhoprice(String phoprice) {
        this.phoprice = phoprice;
    }

    public String getPhoimage() {
        return phoimage;
    }

    public void setPhoimage(String phoimage) {
        this.phoimage = phoimage;
    }

    private String id;
    private String phoname;
    private String phodetail1;
    private String phoprice;
    private String phoimage;














}
