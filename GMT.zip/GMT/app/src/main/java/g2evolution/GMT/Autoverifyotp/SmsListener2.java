package g2evolution.GMT.Autoverifyotp;

/**
 * Created by swarajpal on 19-04-2016.
 */
public interface SmsListener2 {

        public void messageReceived(String messageText);

}
