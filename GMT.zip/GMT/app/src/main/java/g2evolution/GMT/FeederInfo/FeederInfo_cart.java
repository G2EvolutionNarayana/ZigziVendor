package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_cart {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCartname() {
        return cartname;
    }

    public void setCartname(String cartname) {
        this.cartname = cartname;
    }

    public String getCartprodetails() {
        return cartprodetails;
    }

    public void setCartprodetails(String cartprodetails) {
        this.cartprodetails = cartprodetails;
    }

    public String getCartamount() {
        return cartamount;
    }

    public void setCartamount(String cartamount) {
        this.cartamount = cartamount;
    }

    public String getCartquantity() {
        return cartquantity;
    }

    public void setCartquantity(String cartquantity) {
        this.cartquantity = cartquantity;
    }

    public String getCartimage() {
        return cartimage;
    }

    public void setCartimage(String cartimage) {
        this.cartimage = cartimage;
    }

    public String getButdecrement() {
        return butdecrement;
    }

    public void setButdecrement(String butdecrement) {
        this.butdecrement = butdecrement;
    }

    public String getButincrement() {
        return butincrement;
    }

    public void setButincrement(String butincrement) {
        this.butincrement = butincrement;
    }

    private String id;
    private String cartname;
    private String cartprodetails;
    private String cartamount;
    private String cartquantity;
    private String cartimage;
    private String butdecrement;
    private String butincrement;
    private String discountvalue;
    private String afterdiscount;
    private String stockquntity;
    private String producttotal;

    public String getStockquntity() {
        return stockquntity;
    }

    public void setStockquntity(String stockquntity) {
        this.stockquntity = stockquntity;
    }

    public String getDiscountvalue() {
        return discountvalue;
    }

    public void setDiscountvalue(String discountvalue) {
        this.discountvalue = discountvalue;
    }

    public String getAfterdiscount() {
        return afterdiscount;
    }

    public void setAfterdiscount(String afterdiscount) {
        this.afterdiscount = afterdiscount;
    }

    public String getCarttotalamount() {
        return carttotalamount;
    }

    public void setCarttotalamount(String carttotalamount) {
        this.carttotalamount = carttotalamount;
    }

    private String carttotalamount;

    public String getProducttotal() {
        return producttotal;
    }

    public void setProducttotal(String producttotal) {
        this.producttotal = producttotal;
    }
}
