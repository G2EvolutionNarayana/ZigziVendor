package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_grocery {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGroname() {
        return groname;
    }

    public void setGroname(String groname) {
        this.groname = groname;
    }

    public String getGrodetail1() {
        return grodetail1;
    }

    public void setGrodetail1(String grodetail1) {
        this.grodetail1 = grodetail1;
    }

    public String getGroprice() {
        return groprice;
    }

    public void setGroprice(String groprice) {
        this.groprice = groprice;
    }

    public String getGroimage() {
        return groimage;
    }

    public void setGroimage(String groimage) {
        this.groimage = groimage;
    }

    private String id;
    private String groname;
    private String grodetail1;
    private String groprice;
    private String groimage;














}
