package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_home_category {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public String getElectronicname() {
        return electronicname;
    }

    public void setElectronicname(String electronicname) {
        this.electronicname = electronicname;
    }

    public String getElectronicdetail1() {
        return electronicdetail1;
    }

    public void setElectronicdetail1(String electronicdetail1) {
        this.electronicdetail1 = electronicdetail1;
    }

    public String getElectronicdetail2() {
        return electronicdetail2;
    }

    public void setElectronicdetail2(String electronicdetail2) {
        this.electronicdetail2 = electronicdetail2;
    }

    public String getElectronicprice() {
        return electronicprice;
    }

    public void setElectronicprice(String electronicprice) {
        this.electronicprice = electronicprice;
    }

    public String getElectronicimage() {
        return electronicimage;
    }

    public void setElectronicimage(String electronicimage) {
        this.electronicimage = electronicimage;
    }

    public String getDiscountvalue() {
        return discountvalue;
    }

    public void setDiscountvalue(String discountvalue) {
        this.discountvalue = discountvalue;
    }

    public String getAfterdiscount() {
        return afterdiscount;
    }

    public void setAfterdiscount(String afterdiscount) {
        this.afterdiscount = afterdiscount;
    }

    private String id;
    private String categoryname;
    private String electronicname;
    private String electronicdetail1;
    private String electronicdetail2;
    private String electronicprice;
    private String electronicimage;
    private String discountvalue;
    private String afterdiscount;
    private String categoryimage;

    private String subcateid;

    public String getSubcateid() {
        return subcateid;
    }

    public void setSubcateid(String subcateid) {
        this.subcateid = subcateid;
    }

    public String getCategoryimage() {
        return categoryimage;
    }

    public void setCategoryimage(String categoryimage) {
        this.categoryimage = categoryimage;
    }
}
