package g2evolution.GMT.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import g2evolution.GMT.R;


/**
 * Created by G2e Android on 23-01-2018.
 */

public class Fragment_aboutus extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.aboutus, container, false);


        return rootView;
    }
}
