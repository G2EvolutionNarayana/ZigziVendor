package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_review {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTextrating() {
        return textrating;
    }

    public void setTextrating(String textrating) {
        this.textrating = textrating;
    }

    public String getTexttitle() {
        return texttitle;
    }

    public void setTexttitle(String texttitle) {
        this.texttitle = texttitle;
    }

    public String getTextdesc() {
        return textdesc;
    }

    public void setTextdesc(String textdesc) {
        this.textdesc = textdesc;
    }

    public String getTexton() {
        return texton;
    }

    public void setTexton(String texton) {
        this.texton = texton;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String id;
    private String textrating;
    private String texttitle;
    private String textdesc;
    private String texton;
    private String name;















}
