package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_main {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTextnavi() {
        return textnavi;
    }

    public void setTextnavi(String textnavi) {
        this.textnavi = textnavi;
    }

    private String id;
    private String textnavi;















}
