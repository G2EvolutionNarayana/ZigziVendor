package g2evolution.GMT.FeederInfo;

/**
 * Created by soumyaPC on 4/28/2016.
 */
public class Spinner_model {

    private String Name;
    private String Id;

    public String getName() {
        return Name;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public void setName(String name) {
        Name = name;
    }
}
