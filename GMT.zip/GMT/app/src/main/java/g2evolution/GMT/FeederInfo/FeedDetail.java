package g2evolution.GMT.FeederInfo;

/**
 * Created by brajabasi on 17-03-2016.
 */
public class FeedDetail {
    String Title;
    public FeedDetail(){}

    public FeedDetail(String title){
        Title = title;

    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }


}

