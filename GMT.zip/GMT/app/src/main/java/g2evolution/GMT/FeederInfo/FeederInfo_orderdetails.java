package g2evolution.GMT.FeederInfo;

/**
 * Created by G2e Android on 17-05-2017.
 */

public class FeederInfo_orderdetails {


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(String orderdate) {
        this.orderdate = orderdate;
    }

    public String getOrdername() {
        return ordername;
    }

    public void setOrdername(String ordername) {
        this.ordername = ordername;
    }

    public String getOrderprodetails() {
        return orderprodetails;
    }

    public void setOrderprodetails(String orderprodetails) {
        this.orderprodetails = orderprodetails;
    }

    public String getOrderpriceamount() {
        return orderpriceamount;
    }

    public void setOrderpriceamount(String orderpriceamount) {
        this.orderpriceamount = orderpriceamount;
    }

    public String getQuantity_ordertext() {
        return quantity_ordertext;
    }

    public void setQuantity_ordertext(String quantity_ordertext) {
        this.quantity_ordertext = quantity_ordertext;
    }

    public String getOrdertotalamount() {
        return ordertotalamount;
    }

    public void setOrdertotalamount(String ordertotalamount) {
        this.ordertotalamount = ordertotalamount;
    }

    public String getOrderimage() {
        return orderimage;
    }

    public void setOrderimage(String orderimage) {
        this.orderimage = orderimage;
    }

    public String getOrderdelet() {
        return orderdelet;
    }

    public void setOrderdelet(String orderdelet) {
        this.orderdelet = orderdelet;
    }

    public String getDiscountvalue() {
        return discountvalue;
    }

    public void setDiscountvalue(String discountvalue) {
        this.discountvalue = discountvalue;
    }

    public String getAfterdiscount() {
        return afterdiscount;
    }

    public void setAfterdiscount(String afterdiscount) {
        this.afterdiscount = afterdiscount;
    }

    public String getDiscountamount() {
        return discountamount;
    }

    public void setDiscountamount(String discountamount) {
        this.discountamount = discountamount;
    }

    private String id;
    private String orderdate;
    private String ordername;
    private String orderprodetails;
    private String orderpriceamount;
    private String quantity_ordertext;
    private String ordertotalamount;
    private String orderimage;
    private String orderdelet;
    private String discountvalue;
    private String afterdiscount;
    private String discountamount;












}
